// DlgFireDetection.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgFireDetection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgFireDetection dialog


CDlgFireDetection::CDlgFireDetection(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgFireDetection::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgFireDetection)
	m_bEnable = FALSE;
	m_bFireRegionOverlay = FALSE;
	m_byFireComfirmTime = 0;
	m_bySensitivity = 0;
	m_byFocusZoom = 0;
	m_bManualRangEnable = FALSE;
	//}}AFX_DATA_INIT
    m_lChannel = -1;
    m_lUser = -1;
    m_iDeviceIndex = -1;
    memset(m_szStatusBuf, 0, ISAPI_STATUS_LEN);
    memset(&m_struFireDetection, 0, sizeof(m_struFireDetection));
}


void CDlgFireDetection::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgFireDetection)
	DDX_Check(pDX, IDC_CHK_ENABLE, m_bEnable);
	DDX_Check(pDX, IDC_CHK_FIREREG_OVERLAY, m_bFireRegionOverlay);
	DDX_Text(pDX, IDC_EDIT_FIRE_COMFIRM_TIME, m_byFireComfirmTime);
	DDX_Text(pDX, IDC_EDIT_SENSITIVITY, m_bySensitivity);
	DDX_Text(pDX, IDC_EDIT_FOCUSZOOM, m_byFocusZoom);
	DDX_Check(pDX, IDC_CHK_MANUALRANGING_ENABLE, m_bManualRangEnable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgFireDetection, CDialog)
	//{{AFX_MSG_MAP(CDlgFireDetection)
	ON_BN_CLICKED(IDC_BTN_GET, OnBtnGet)
	ON_BN_CLICKED(IDC_BTN_SET, OnBtnSet)
	ON_BN_CLICKED(IDC_BTN_SET_MANUALRANGING, OnBtnSetManualranging)
	ON_BN_CLICKED(IDC_BTN_GET_MANUALRANGING, OnBtnGetManualranging)
	ON_BN_CLICKED(IDC_BTN_FOCUSZOOM, OnBtnFocuszoom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgFireDetection message handlers

BOOL CDlgFireDetection::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	OnBtnGet();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgFireDetection::OnBtnGet() 
{
	// TODO: Add your control notification handler code here
    memset(&m_struFireDetection, 0, sizeof(m_struFireDetection));

    NET_DVR_STD_CONFIG struCfg = {0};
    struCfg.lpCondBuffer = &m_lChannel;
    struCfg.dwCondSize = sizeof(m_lChannel);
    struCfg.lpOutBuffer = &m_struFireDetection;
    struCfg.dwOutSize = sizeof(m_struFireDetection);
    memset(m_szStatusBuf, 0, ISAPI_STATUS_LEN);
    struCfg.lpStatusBuffer = m_szStatusBuf;
    struCfg.dwStatusSize = ISAPI_STATUS_LEN;
    if(!NET_DVR_GetSTDConfig(m_lUser, NET_DVR_GET_FIREDETECTION, &struCfg))
    {
        OutputDebugString(m_szStatusBuf);
        g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_FAIL_T, "NET_DVR_GET_FIREDETECTION");
    }
    else
    {
        g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_SUCC_T, "NET_DVR_GET_FIREDETECTION");
    }

    m_bEnable = m_struFireDetection.byEnabled;
    m_bySensitivity = m_struFireDetection.bySensitivity;
    m_byFireComfirmTime = m_struFireDetection.byFireComfirmTime;
    m_bFireRegionOverlay = m_struFireDetection.byFireRegionOverlay;
 //   m_byFocusZoom = m_struFireDetection.byFocusZoom;
    UpdateData(FALSE);
}

void CDlgFireDetection::OnBtnSet() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
    memset(&m_struFireDetection, 0, sizeof(m_struFireDetection));

    m_struFireDetection.byEnabled = m_bEnable;
    m_struFireDetection.bySensitivity = m_bySensitivity;
    m_struFireDetection.byFireComfirmTime = m_byFireComfirmTime;
    m_struFireDetection.byFireRegionOverlay = m_bFireRegionOverlay;
 //   m_struFireDetection.byFocusZoom = m_byFocusZoom;
    m_struFireDetection.dwSize = sizeof(m_struFireDetection);
    
    NET_DVR_STD_CONFIG struCfg = {0};
    struCfg.lpCondBuffer = &m_lChannel;
    struCfg.dwCondSize = sizeof(m_lChannel);
    struCfg.lpInBuffer = &m_struFireDetection;
    struCfg.dwInSize = sizeof(m_struFireDetection);
    memset(m_szStatusBuf, 0, ISAPI_STATUS_LEN);
    struCfg.lpStatusBuffer = m_szStatusBuf;
    struCfg.dwStatusSize = ISAPI_STATUS_LEN;
    
    if(!NET_DVR_SetSTDConfig(m_lUser, NET_DVR_SET_FIREDETECTION, &struCfg))
    {
        OutputDebugString(m_szStatusBuf);
        g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_FAIL_T, "NET_DVR_SET_FIREDETECTION");
    }
    else
    {
        g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_SUCC_T, "NET_DVR_SET_FIREDETECTION");
    }
}

void CDlgFireDetection::OnBtnSetManualranging() 
{
	// TODO: Add your control notification handler code here
    UpdateData(TRUE);

    NET_DVR_MANUALRANGING_CFG struManualRangCfg = {0};
    struManualRangCfg.byEnabled = m_bManualRangEnable;

    struManualRangCfg.dwSize = sizeof(struManualRangCfg);
    
    NET_DVR_STD_CONFIG struCfg = {0};
    struCfg.lpCondBuffer = &m_lChannel;
    struCfg.dwCondSize = sizeof(m_lChannel);
    struCfg.lpInBuffer = &struManualRangCfg;
    struCfg.dwInSize = sizeof(struManualRangCfg);
    memset(m_szStatusBuf, 0, ISAPI_STATUS_LEN);
    struCfg.lpStatusBuffer = m_szStatusBuf;
    struCfg.dwStatusSize = ISAPI_STATUS_LEN;
    
    if(!NET_DVR_SetSTDConfig(m_lUser, NET_DVR_SET_MANUALRANGING, &struCfg))
    {
        OutputDebugString(m_szStatusBuf);
        g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_FAIL_T, "NET_DVR_SET_MANUALRANGING");
    }
    else
    {
        g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_SUCC_T, "NET_DVR_SET_MANUALRANGING");
    }
}

void CDlgFireDetection::OnBtnGetManualranging() 
{
    // TODO: Add your control notification handler code here
//     NET_DVR_MANUALRANGING_CFG struManualRangCfg = {0};
//     
//     NET_DVR_STD_CONFIG struCfg = {0};
//     struCfg.lpCondBuffer = &m_lChannel;
//     struCfg.dwCondSize = sizeof(m_lChannel);
//     struCfg.lpOutBuffer = &struManualRangCfg;
//     struCfg.dwOutSize = sizeof(struManualRangCfg);
//     memset(m_szStatusBuf, 0, ISAPI_STATUS_LEN);
//     struCfg.lpStatusBuffer = m_szStatusBuf;
//     struCfg.dwStatusSize = ISAPI_STATUS_LEN;
//     if(!NET_DVR_GetSTDConfig(m_lUser, NET_DVR_GET_MANUALRANGING, &struCfg))
//     {
//         OutputDebugString(m_szStatusBuf);
//         g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_FAIL_T, "NET_DVR_GET_MANUALRANGING");
//     }
//     else
//     {
//         g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_SUCC_T, "NET_DVR_GET_MANUALRANGING");
//     }
//     
//     m_bManualRangEnable = struManualRangCfg.byEnabled;
//     UpdateData(FALSE);
    
}

void CDlgFireDetection::OnBtnFocuszoom() 
{
	// TODO: Add your control notification handler code here
    UpdateData(TRUE);

    NET_DVR_STD_CONTROL struStdControl = {0};
    struStdControl.lpCondBuffer = &m_lChannel;
    struStdControl.dwCondSize = sizeof(m_lChannel);
    memset(m_szStatusBuf, 0, ISAPI_STATUS_LEN);
    struStdControl.lpStatusBuffer = m_szStatusBuf;
    struStdControl.dwStatusSize = ISAPI_STATUS_LEN;
    if (!NET_DVR_STDControl(m_lUser, NET_DVR_FIRE_FOCUSZOOM_CTRL, &struStdControl))
    {
        OutputDebugString(m_szStatusBuf);
        g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_FAIL_T, "NET_DVR_FIRE_FOCUSZOOM_CTRL");
    }
    else
    {
        OutputDebugString(m_szStatusBuf);
        g_pMainDlg->AddLog(m_iDeviceIndex,  OPERATION_SUCC_T, "NET_DVR_FIRE_FOCUSZOOM_CTRL");
	}
}

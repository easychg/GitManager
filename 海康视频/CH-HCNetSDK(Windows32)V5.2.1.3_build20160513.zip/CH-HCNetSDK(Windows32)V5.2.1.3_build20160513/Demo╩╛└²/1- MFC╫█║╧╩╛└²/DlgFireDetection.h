#if !defined(AFX_DLGFIREDETECTION_H__A89643A0_26F1_4E88_9B73_BD639787EC2E__INCLUDED_)
#define AFX_DLGFIREDETECTION_H__A89643A0_26F1_4E88_9B73_BD639787EC2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgFireDetection.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgFireDetection dialog

class CDlgFireDetection : public CDialog
{
// Construction
public:
	CDlgFireDetection(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgFireDetection)
	enum { IDD = IDD_DLG_FIRE_DETECTION };
	BOOL	m_bEnable;
	BOOL	m_bFireRegionOverlay;
	BYTE	m_byFireComfirmTime;
	BYTE	m_bySensitivity;
	BYTE	m_byFocusZoom;
	BOOL	m_bManualRangEnable;
	//}}AFX_DATA
    LONG    m_lChannel;
    LONG    m_lUser;
    int     m_iDeviceIndex;
    char    m_szStatusBuf[ISAPI_STATUS_LEN];
    NET_DVR_FIREDETECTION_CFG m_struFireDetection;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgFireDetection)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgFireDetection)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnGet();
	afx_msg void OnBtnSet();
	afx_msg void OnBtnSetManualranging();
	afx_msg void OnBtnGetManualranging();
	afx_msg void OnBtnFocuszoom();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGFIREDETECTION_H__A89643A0_26F1_4E88_9B73_BD639787EC2E__INCLUDED_)

#if !defined(AFX_DLGCARDREADERCFG_H__A7DE20F8_FEBB_4919_87A1_B62B03464A76__INCLUDED_)
#define AFX_DLGCARDREADERCFG_H__A7DE20F8_FEBB_4919_87A1_B62B03464A76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCardReaderCfg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgCardReaderCfg dialog

class CDlgCardReaderCfg : public CDialog
{
// Construction
public:
	CDlgCardReaderCfg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCardReaderCfg)
	enum { IDD = IDD_DLG_AC_CARDREADERCFG };
	CComboBox	m_cmbType;
	CComboBox	m_cmbBuzzerPolarity;
	CComboBox	m_cmbErrorLed;
	CComboBox	m_cmbOKLed;
	BOOL	m_BEnable;
	BOOL	m_BEnableFailAlarm;
	DWORD	m_dwCardReaderNo;
	DWORD	m_dwSwipeInterval;
	DWORD	m_dwPressTimeOut;
	DWORD	m_dwMaxReadCardFailNum;
	BOOL	m_BEnableTamperCheck;
	DWORD	m_dwOfflineCheckTime;
    DWORD	m_byFingerPrintCheckLevel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCardReaderCfg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCardReaderCfg)
	afx_msg void OnButGet();
	afx_msg void OnButSet();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
    int m_iUserID; 
    int m_iDeviceID; 
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCARDREADERCFG_H__A7DE20F8_FEBB_4919_87A1_B62B03464A76__INCLUDED_)

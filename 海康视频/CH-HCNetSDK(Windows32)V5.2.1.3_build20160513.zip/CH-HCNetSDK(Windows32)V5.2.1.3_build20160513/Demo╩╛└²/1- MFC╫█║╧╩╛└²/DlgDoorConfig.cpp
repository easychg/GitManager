// DlgDoorConfig.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgDoorConfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgDoorConfig dialog


CDlgDoorConfig::CDlgDoorConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDoorConfig::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgDoorConfig)
	m_dwDoorChan = 1;
	m_csDoorName = _T("");
	m_csStressPasswd = _T("");
	m_csSuperPasswd = _T("");
    m_csUnlockPassword = _T("");
	m_BDoorLock = FALSE;
	m_BLeaderCard = FALSE;
	m_csDOpenDuration = _T("");
	m_csLOpenDuration = _T("");
	m_csOpenDuration = _T("");
	m_csAlarmTimeout = _T("");
	//}}AFX_DATA_INIT
}


void CDlgDoorConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDoorConfig)
	DDX_Control(pDX, IDC_COM_ACDC_OPENBUTTONTYPE, m_cmbOpenButType);
	DDX_Control(pDX, IDC_COM_ACDC_MAGNETICTYPE, m_cmbMagneticType);
	DDX_Control(pDX, IDC_SLIDER_ACDC_LEADEROPENDURATION, m_SlidLOpenDuration);
	DDX_Control(pDX, IDC_SLIDER_ACDC_DISABLEDOPENDURATION, m_SlidDOpenDuration);
	DDX_Control(pDX, IDC_SLIDER_ACDC_ALARMTIMEOUT, m_SlidAlarmTimeout);
	DDX_Control(pDX, IDC_SLIDER_ACDC_OPENDURATION, m_SlidOpenDuration);
	DDX_Text(pDX, IDC_EDT_ACDC_DOORCHANNEL, m_dwDoorChan);
	DDX_Text(pDX, IDC_EDT_ACDC_DOORNAME, m_csDoorName);
	DDX_Text(pDX, IDC_EDT_ACDC_STRESSPASSWORD, m_csStressPasswd);
	DDX_Text(pDX, IDC_EDT_ACDC_SUPERPASSWORD, m_csSuperPasswd);
    DDX_Text(pDX, IDC_EDT_ACDC_UNLOCKPASSWORD, m_csUnlockPassword);
	DDX_Check(pDX, IDC_CHK_ACDC_DOORLOCK, m_BDoorLock);
	DDX_Check(pDX, IDC_CHK_ACDC_LEADERCARD, m_BLeaderCard);
	DDX_Text(pDX, IDC_STATIC_ACDC_DOPENDURATION, m_csDOpenDuration);
	DDX_Text(pDX, IDC_STATIC_ACDC_LOPENDURATION, m_csLOpenDuration);
	DDX_Text(pDX, IDC_STATIC_ACDC_OPENDURATION, m_csOpenDuration);
	DDX_Text(pDX, IDC_STATIC_ADSC_ALARMTIMEOUT, m_csAlarmTimeout);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgDoorConfig, CDialog)
	//{{AFX_MSG_MAP(CDlgDoorConfig)
	ON_BN_CLICKED(IDC_BUT_ACDC_GET, OnButGet)
	ON_BN_CLICKED(IDC_BUT_ACDC_SET, OnButSet)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_ACDC_OPENDURATION, OnCdrawOpenduration)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_ACDC_DISABLEDOPENDURATION, OnCdrawDOpenduration)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_ACDC_LEADEROPENDURATION, OnCdrawLOpenduration)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_ACDC_ALARMTIMEOUT, OnCdrawAlarmtimeout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDoorConfig message handlers



BOOL CDlgDoorConfig::OnInitDialog() 
{
	CDialog::OnInitDialog();
    m_lDeviceID = g_pMainDlg->GetCurDeviceIndex(); 
    m_lUserID = g_struDeviceInfo[m_lDeviceID].lLoginID; 
	// TODO: Add extra initialization here
	m_SlidOpenDuration.SetRange(1, 255); 
    m_SlidDOpenDuration.SetRange(1, 255); 
    m_SlidLOpenDuration.SetRange(1, 1440);
    m_SlidAlarmTimeout.SetRange(0, 255);
    m_SlidOpenDuration.SetPos(1); 
    m_SlidDOpenDuration.SetPos(1); 
    m_SlidLOpenDuration.SetPos(1); 
    m_SlidAlarmTimeout.SetPos(0);
    m_csOpenDuration = " "; 
    m_csDOpenDuration = " "; 
    m_csLOpenDuration = " "; 
    m_csAlarmTimeout = " "; 
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDlgDoorConfig::OnButGet() 
{
    // TODO: Add your control notification handler code here
    UpdateData(TRUE); 
    DWORD dwReturned; 
    NET_DVR_DOOR_CFG struDoorCfg = {0}; 
    char szLan[128]; 
    if (!NET_DVR_GetDVRConfig(m_lUserID, NET_DVR_GET_DOOR_CFG, m_dwDoorChan, &struDoorCfg, sizeof(struDoorCfg), &dwReturned) )
    {
        sprintf(szLan, "NET_DVR_GET_DOOR_CFG, Error code %d", NET_DVR_GetLastError());
        MessageBox(szLan); 
        g_pMainDlg->AddLog(m_lDeviceID, OPERATION_FAIL_T, "NET_DVR_GET_DOOR_CFG"); 
        return ; 
    }
    else
    {
        g_pMainDlg->AddLog(m_lDeviceID, OPERATION_SUCC_T, "NET_DVR_GET_DOOR_CFG"); 
		char szName[DOOR_NAME_LEN+1] = {0}; 
		memcpy(szName, struDoorCfg.byDoorName,  DOOR_NAME_LEN);  
        m_csDoorName.Format("%s", szName) ;
        m_BDoorLock = struDoorCfg.byEnableDoorLock; 
        m_BLeaderCard = struDoorCfg.byEnableLeaderCard; 
        UpdateData(FALSE); 

        m_cmbMagneticType.SetCurSel(struDoorCfg.byMagneticType); 
        m_cmbOpenButType.SetCurSel(struDoorCfg.byOpenButtonType); 
        m_SlidOpenDuration.SetPos(struDoorCfg.byOpenDuration); 
        m_csOpenDuration.Format("%d (s)", struDoorCfg.byOpenDuration); 
        m_SlidDOpenDuration.SetPos(struDoorCfg.byDisabledOpenDuration); 
        m_csDOpenDuration.Format("%d (s)", struDoorCfg.byDisabledOpenDuration); 
        m_SlidLOpenDuration.SetPos(struDoorCfg.dwLeaderCardOpenDuration); 
        m_csLOpenDuration.Format("%d (min)", struDoorCfg.dwLeaderCardOpenDuration);
        m_SlidAlarmTimeout.SetPos(struDoorCfg.byMagneticAlarmTimeout); 
        m_csAlarmTimeout.Format("%d (s)", struDoorCfg.byMagneticAlarmTimeout); 
        char szPassWord[STRESS_PASSWORD_LEN+1];
        szPassWord[STRESS_PASSWORD_LEN] = 0; 
        memcpy(szPassWord, struDoorCfg.byStressPassword, STRESS_PASSWORD_LEN); 
        m_csStressPasswd.Format("%s", szPassWord);

        memset(szPassWord, 0 ,sizeof(szPassWord));
        szPassWord[STRESS_PASSWORD_LEN] = '\0';
        memcpy(szPassWord, struDoorCfg.bySuperPassword, SUPER_PASSWORD_LEN);
        m_csSuperPasswd.Format("%s", szPassWord);

        memset(szPassWord, 0 ,sizeof(szPassWord));
        szPassWord[STRESS_PASSWORD_LEN] = '\0';
        memcpy(szPassWord, struDoorCfg.byUnlockPassword, UNLOCK_PASSWORD_LEN);
        m_csUnlockPassword.Format("%s", szPassWord);

        UpdateData(FALSE); 
    }
}

void CDlgDoorConfig::OnButSet() 
{
    // TODO: Add your control notification handler code here
    UpdateData(TRUE);
    NET_DVR_DOOR_CFG struDoorCfg = {0}; 
    struDoorCfg.dwSize = sizeof(struDoorCfg);
	strncpy((char *)struDoorCfg.byDoorName, (LPCTSTR)m_csDoorName, DOOR_NAME_LEN); 
    struDoorCfg.byMagneticType = m_cmbMagneticType.GetCurSel();
    struDoorCfg.byOpenButtonType = m_cmbOpenButType.GetCurSel(); 
    struDoorCfg.byEnableDoorLock = m_BDoorLock;
    struDoorCfg.byEnableLeaderCard = m_BLeaderCard;

    struDoorCfg.byOpenDuration = m_SlidOpenDuration.GetPos(); 
    struDoorCfg.byDisabledOpenDuration = m_SlidDOpenDuration.GetPos(); 
    struDoorCfg.dwLeaderCardOpenDuration = m_SlidLOpenDuration.GetPos(); 
    struDoorCfg.byMagneticAlarmTimeout = m_SlidAlarmTimeout.GetPos(); 

    strncpy((char *)struDoorCfg.byStressPassword, (LPCTSTR)m_csStressPasswd, STRESS_PASSWORD_LEN);
    strncpy((char *)struDoorCfg.bySuperPassword, (LPCTSTR)m_csSuperPasswd, SUPER_PASSWORD_LEN);
    strncpy((char *)struDoorCfg.byUnlockPassword, (LPCTSTR)m_csUnlockPassword, UNLOCK_PASSWORD_LEN);

    char szLan[128];
    if (!NET_DVR_SetDVRConfig(m_lUserID, NET_DVR_SET_DOOR_CFG, m_dwDoorChan, &struDoorCfg, sizeof(struDoorCfg)))
    {
        sprintf(szLan, "NET_DVR_SET_DOOR_CFG, Error Code %d", NET_DVR_GetLastError());
        MessageBox(szLan); 
        g_pMainDlg->AddLog(m_lDeviceID, OPERATION_FAIL_T, "NET_DVR_SET_DOOR_CFG");
        return ; 
    }
    else
    {
        g_pMainDlg->AddLog(m_lDeviceID, OPERATION_SUCC_T, "NET_DVR_SET_DOOR_CFG");
	}
}

void CDlgDoorConfig::OnCdrawOpenduration(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE); 
    m_csOpenDuration.Format("%d (s)", m_SlidOpenDuration.GetPos()); 
    UpdateData(FALSE); 
	*pResult = 0;
}

void CDlgDoorConfig::OnCdrawDOpenduration(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
    UpdateData(TRUE); 
    m_csDOpenDuration.Format("%d (s)", m_SlidDOpenDuration.GetPos()); 
    UpdateData(FALSE); 
	*pResult = 0;
}

void CDlgDoorConfig::OnCdrawLOpenduration(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
    UpdateData(TRUE); 
    m_csLOpenDuration.Format("%d (min)", m_SlidLOpenDuration.GetPos()); 
    UpdateData(FALSE); 
	*pResult = 0;
}

void CDlgDoorConfig::OnCdrawAlarmtimeout(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
    UpdateData(TRUE); 
    m_csAlarmTimeout.Format("%d (s)", m_SlidAlarmTimeout.GetPos()); 
    UpdateData(FALSE); 
	*pResult = 0;
}

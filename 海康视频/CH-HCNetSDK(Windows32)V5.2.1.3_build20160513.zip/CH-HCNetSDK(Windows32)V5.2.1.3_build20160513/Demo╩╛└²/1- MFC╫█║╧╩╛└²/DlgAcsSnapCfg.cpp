// DlgAcsSnapCfg.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgAcsSnapCfg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DlgAcsSnapCfg dialog


DlgAcsSnapCfg::DlgAcsSnapCfg(CWnd* pParent /*=NULL*/)
	: CDialog(DlgAcsSnapCfg::IDD, pParent)
{
	//{{AFX_DATA_INIT(DlgAcsSnapCfg)
	m_dwSnapTimes = 0;
    m_IntervalTime1 = 0;
    m_IntervalTime2 = 0;
    m_IntervalTime3 = 0;
    m_IntervalTime4 = 0;
	//}}AFX_DATA_INIT
}


void DlgAcsSnapCfg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgAcsSnapCfg)
	DDX_Text(pDX, IDC_EDIT_TIMES, m_dwSnapTimes);
    DDX_Text(pDX, IDC_EDIT_INTERVAL_TIME1, m_IntervalTime1);
    DDX_Text(pDX, IDC_EDIT_INTERVAL_TIME2, m_IntervalTime2);
    DDX_Text(pDX, IDC_EDIT_INTERVAL_TIME3, m_IntervalTime3);
    DDX_Text(pDX, IDC_EDIT_INTERVAL_TIME4, m_IntervalTime4);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgAcsSnapCfg, CDialog)
	//{{AFX_MSG_MAP(DlgAcsSnapCfg)
    ON_BN_CLICKED(IDC_BUTTON_SET, OnSet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgAcsSnapCfg message handlers

BOOL DlgAcsSnapCfg::OnInitDialog() 
{
    CDialog::OnInitDialog();
    
    UpdateData(TRUE);
    DWORD dwDeviceIndex = g_pMainDlg->GetCurDeviceIndex();
    
    UpdateData(FALSE);
    return TRUE;
}
void DlgAcsSnapCfg::OnSet()
{
    // TODO: Add your control notification handler code here
    UpdateData(TRUE);
    m_struSnapCfg.bySnapTimes = m_dwSnapTimes;
    m_struSnapCfg.wIntervalTime[0] = m_IntervalTime1;
    m_struSnapCfg.wIntervalTime[1] = m_IntervalTime2;
    m_struSnapCfg.wIntervalTime[2] = m_IntervalTime3;
    m_struSnapCfg.wIntervalTime[3] = m_IntervalTime4;
   
    m_struSnapCfg.dwSize = sizeof(m_struSnapCfg);
    
    DWORD dwDeviceIndex = g_pMainDlg->GetCurDeviceIndex();
    char szLan[128] = {0};
    if(NET_DVR_ContinuousShoot(g_struDeviceInfo[dwDeviceIndex].lLoginID, &m_struSnapCfg))
    {
        g_pMainDlg->AddLog(g_struDeviceInfo[dwDeviceIndex].lLoginID, OPERATION_SUCC_T, "NET_DVR_ContinuousShoot SUCC");
        g_StringLanType(szLan, "���óɹ�", "NET_DVR_ContinuousShoot successed!");
        AfxMessageBox(szLan);
    }
    else
    {
        g_pMainDlg->AddLog(g_struDeviceInfo[dwDeviceIndex].lLoginID, OPERATION_FAIL_T, "NET_DVR_ContinuousShoot Failed");
        g_StringLanType(szLan, "����ʧ��", "NET_DVR_ContinuousShoot failed!");
        AfxMessageBox(szLan);
    }
}


#if !defined(AFX_DLGINFODIFFUSIONSHUTDOWN_H__3C1E4190_69C7_488D_B907_2B57017085F2__INCLUDED_)
#define AFX_DLGINFODIFFUSIONSHUTDOWN_H__3C1E4190_69C7_488D_B907_2B57017085F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInfoDiffusionShutdown.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgInfoDiffusionShutdown dialog

class CDlgInfoDiffusionShutdown : public CDialog
{
// Construction
public:
	CDlgInfoDiffusionShutdown(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgInfoDiffusionShutdown)
	enum { IDD = IDD_DLG_INFO_DIFFUSION_SHUTDOWN };
	CListCtrl	m_listSpan;
	CListCtrl	m_listPlan;
	CComboBox	m_cmbWeekday;
	CComboBox	m_cmbPlanType;
	COleDateTime	m_tmDate;
	COleDateTime	m_tmTime;
	CString	m_sPlanName;
	DWORD	m_dwPlanNo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgInfoDiffusionShutdown)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgInfoDiffusionShutdown)
	afx_msg void OnBtnPlanDel();
	afx_msg void OnBtnPlanGet();
	afx_msg void OnBtnPlanGetall();
	afx_msg void OnBtnPlanNew();
	afx_msg void OnBtnPlanSet();
	afx_msg void OnBtnPlanSpanAdd();
	afx_msg void OnBtnPlanSpanDel();
	afx_msg void OnBtnPlanSpanMod();
	afx_msg void OnBtnSwitchPlanExit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINFODIFFUSIONSHUTDOWN_H__3C1E4190_69C7_488D_B907_2B57017085F2__INCLUDED_)

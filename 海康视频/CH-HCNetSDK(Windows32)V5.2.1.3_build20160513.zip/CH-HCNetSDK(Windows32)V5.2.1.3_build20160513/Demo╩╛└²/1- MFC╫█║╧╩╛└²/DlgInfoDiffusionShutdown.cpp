// DlgInfoDiffusionShutdown.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgInfoDiffusionShutdown.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInfoDiffusionShutdown dialog


CDlgInfoDiffusionShutdown::CDlgInfoDiffusionShutdown(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInfoDiffusionShutdown::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInfoDiffusionShutdown)
	m_tmDate = COleDateTime::GetCurrentTime();
	m_tmTime = COleDateTime::GetCurrentTime();
	m_sPlanName = _T("");
	m_dwPlanNo = 0;
	//}}AFX_DATA_INIT
}


void CDlgInfoDiffusionShutdown::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInfoDiffusionShutdown)
	DDX_Control(pDX, IDC_LIST_SPAN, m_listSpan);
	DDX_Control(pDX, IDC_LIST_PLAN, m_listPlan);
	DDX_Control(pDX, IDC_COMBO_WEEKDAY, m_cmbWeekday);
	DDX_Control(pDX, IDC_COMBO_PLAN_TYPE, m_cmbPlanType);
	DDX_DateTimeCtrl(pDX, IDC_DATETIME_DATE, m_tmDate);
	DDX_DateTimeCtrl(pDX, IDC_DATETIME_TIME, m_tmTime);
	DDX_Text(pDX, IDC_EDIT_PLAN_NAME, m_sPlanName);
	DDX_Text(pDX, IDC_EDIT_PLAN_NO, m_dwPlanNo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInfoDiffusionShutdown, CDialog)
	//{{AFX_MSG_MAP(CDlgInfoDiffusionShutdown)
	ON_BN_CLICKED(IDC_BTN_PLAN_DEL, OnBtnPlanDel)
	ON_BN_CLICKED(IDC_BTN_PLAN_GET, OnBtnPlanGet)
	ON_BN_CLICKED(IDC_BTN_PLAN_GETALL, OnBtnPlanGetall)
	ON_BN_CLICKED(IDC_BTN_PLAN_NEW, OnBtnPlanNew)
	ON_BN_CLICKED(IDC_BTN_PLAN_SET, OnBtnPlanSet)
	ON_BN_CLICKED(IDC_BTN_PLAN_SPAN_ADD, OnBtnPlanSpanAdd)
	ON_BN_CLICKED(IDC_BTN_PLAN_SPAN_DEL, OnBtnPlanSpanDel)
	ON_BN_CLICKED(IDC_BTN_PLAN_SPAN_MOD, OnBtnPlanSpanMod)
	ON_BN_CLICKED(IDC_BTN_SWITCH_PLAN_EXIT, OnBtnSwitchPlanExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInfoDiffusionShutdown message handlers

void CDlgInfoDiffusionShutdown::OnBtnPlanDel() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnPlanGet() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnPlanGetall() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnPlanNew() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnPlanSet() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnPlanSpanAdd() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnPlanSpanDel() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnPlanSpanMod() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgInfoDiffusionShutdown::OnBtnSwitchPlanExit() 
{
	// TODO: Add your control notification handler code here
	
}

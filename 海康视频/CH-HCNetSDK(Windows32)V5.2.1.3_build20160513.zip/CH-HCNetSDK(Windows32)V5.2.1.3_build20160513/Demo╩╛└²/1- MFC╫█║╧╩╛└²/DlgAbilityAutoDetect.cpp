// DlgAbilityAutoDetect.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgAbilityAutoDetect.h"


#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgAbilityAutoDetect dialog
#define XML_ABILITY_IN_LEN	1024
#define XML_ABILITY_OUT_LEN	3*1024*1024

CDlgAbilityAutoDetect::CDlgAbilityAutoDetect(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAbilityAutoDetect::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAbilityAutoDetect)
	m_strDevAbility = _T("");
	m_strLostAbility = _T("");
	m_dwLastError = 0;
	m_dwReturnValue = 0;
	m_lServerID = -1;
	m_pOutBuf = NULL;
	m_dwAbilityType = 0;
	m_strInputParam = _T("");
    m_bSTDAbility = FALSE;
	//}}AFX_DATA_INIT
	memset(&m_struSdkLocalCfg, 0, sizeof(m_struSdkLocalCfg));
}


void CDlgAbilityAutoDetect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAbilityAutoDetect)
	DDX_Control(pDX, IDC_CMB_STREAM_TYPE, m_cmbStreamType);
	DDX_Control(pDX, IDC_COMBO_CHANNEL, m_cmbChannel);
	DDX_Control(pDX, IDC_CMB_ABILITY_TYPE, m_cmbAbilityType);
	DDX_Text(pDX, IDC_EDT_ABILITY_SHOW, m_strDevAbility);
	DDX_Text(pDX, IDC_EDT_ABILITY_LOST, m_strLostAbility);
	DDX_Text(pDX, IDC_EDT_LAST_ERROR, m_dwLastError);
	DDX_Text(pDX, IDC_EDT_RETURN_VALUE, m_dwReturnValue);
	DDX_Text(pDX, IDC_EDT_INPUT_PARAM, m_strInputParam);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAbilityAutoDetect, CDialog)
	//{{AFX_MSG_MAP(CDlgAbilityAutoDetect)
	ON_BN_CLICKED(IDC_BTN_USE_SIM_ABILITY, OnBtnUseSimAbility)
	ON_BN_CLICKED(IDC_BTN_GET, OnBtnGet)
	ON_WM_DESTROY()
	ON_CBN_SELCHANGE(IDC_CMB_ABILITY_TYPE, OnSelchangeCmbAbilityType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAbilityAutoDetect message handlers

void CDlgAbilityAutoDetect::OnBtnUseSimAbility() 
{
	// TODO: Add your control notification handler code here
	memset(&m_struSdkLocalCfg, 0 ,sizeof(m_struSdkLocalCfg));
	NET_DVR_GetSDKLocalConfig(&m_struSdkLocalCfg);
	
	if (1 == m_struSdkLocalCfg.byEnableAbilityParse)
	{
		m_struSdkLocalCfg.byEnableAbilityParse = 0;
		GetDlgItem(IDC_BTN_USE_SIM_ABILITY)->SetWindowText("��ʹ��ģ������");
	} 
	else
	{
		m_struSdkLocalCfg.byEnableAbilityParse = 1;
		GetDlgItem(IDC_BTN_USE_SIM_ABILITY)->SetWindowText("ʹ��ģ������");
	}
	
	if (!NET_DVR_SetSDKLocalConfig(&m_struSdkLocalCfg))
	{
		AfxMessageBox("fail!");
	}
}

void CDlgAbilityAutoDetect::OnBtnGet() 
{
	// TODO: Add your control notification handler code here
    GetDlgItem(IDC_EDT_ABILITY_SHOW)->SetWindowText("");
    GetDlgItem(IDC_EDT_ABILITY_LOST)->SetWindowText("");
    UpdateData(TRUE);
    if (m_dwAbilityType == 0)
    {
        AfxMessageBox("��ѡ����ȷ������������!");
        return ;
    }
    if (m_bSTDAbility == 1)
    {
        int nID = 0;
        NET_DVR_STD_ABILITY struSTDAbility = {0};
        NET_DVR_REGION_CLIP_COND struCond = {0};
        if(m_dwAbilityType == NET_DVR_GET_REGIONCLIP_CAPABILITIES)
        {
            struCond.dwSize = sizeof(struCond);
            struCond.dwChannel = m_cmbChannel.GetCurSel() + 1;
            struCond.dwStreamType = m_cmbStreamType.GetCurSel();
            struSTDAbility.lpCondBuffer = &struCond;
            struSTDAbility.dwCondSize = sizeof(struCond);
        }
		else if(m_dwAbilityType == NET_DVR_GET_RTMP_CFG_CAP)
        {
			NET_DVR_RTMP_COND struRTMPCond = {0};
            struRTMPCond.dwSize = sizeof(struRTMPCond);
            struRTMPCond.dwChannel = m_cmbChannel.GetCurSel() + 1;
            struRTMPCond.byStreamType = m_cmbStreamType.GetCurSel() + 1;
            struSTDAbility.lpCondBuffer = &struRTMPCond;
            struSTDAbility.dwCondSize = sizeof(struRTMPCond);
        }
        else
        {
            if (m_strInputParam != "")
            {
                nID = atoi(m_strInputParam.GetBuffer(0));
                m_strInputParam.ReleaseBuffer();
            }
            struSTDAbility.lpCondBuffer = &nID;
            struSTDAbility.dwCondSize = sizeof(int);
        }        
        
        struSTDAbility.lpOutBuffer = m_pOutBuf;
        struSTDAbility.dwOutSize = XML_ABILITY_OUT_LEN;
        struSTDAbility.lpStatusBuffer = m_pOutBuf;
        struSTDAbility.dwStatusSize = XML_ABILITY_OUT_LEN;
        m_dwReturnValue = NET_DVR_GetSTDAbility(m_lServerID, m_dwAbilityType, &struSTDAbility);
    }
    else if (m_bSTDAbility == 2)
    {
        NET_DVR_XML_CONFIG_INPUT    struInput = {0};
        NET_DVR_XML_CONFIG_OUTPUT   struOuput = {0};
        struInput.dwSize = sizeof(struInput);
        struInput.lpRequestUrl = m_strInputParam.GetBuffer(0);
        struInput.dwRequestUrlLen = m_strInputParam.GetLength();
		memset(m_pOutBuf, 0, XML_ABILITY_OUT_LEN);
        struOuput.lpOutBuffer = m_pOutBuf;
        struOuput.dwOutBufferSize = XML_ABILITY_OUT_LEN;
        
        m_dwReturnValue = NET_DVR_STDXMLConfig(m_lServerID, &struInput, &struOuput);
    }
    else
    {
        m_dwReturnValue = NET_DVR_GetDeviceAbility(m_lServerID, m_dwAbilityType, m_strInputParam.GetBuffer(0), m_strInputParam.GetLength(), m_pOutBuf, XML_ABILITY_OUT_LEN);
        m_strInputParam.ReleaseBuffer();
    }	
    m_dwLastError = NET_DVR_GetLastError();
    if (m_dwReturnValue != 0)
    {
        CXmlBase xmlBase;
        xmlBase.Parse(m_pOutBuf);
        xmlBase.SetRoot();
        m_strDevAbility = xmlBase.GetChildren().c_str();
        //	m_strDevAbility = m_pOutBuf;
        m_strDevAbility.Replace("\n", "\r\n");
        if (!m_bSTDAbility)
        {
            ParseAbility();
        }		
    }
    
	UpdateData(FALSE);
}

void CDlgAbilityAutoDetect::OnDestroy() 
{
	CDialog::OnDestroy();
	
	if (m_pOutBuf != NULL)
	{
		delete []m_pOutBuf;
		m_pOutBuf = NULL;
	}
}

BOOL CDlgAbilityAutoDetect::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	m_pOutBuf = new char[XML_ABILITY_OUT_LEN];
	memset(m_pOutBuf, 0, XML_ABILITY_OUT_LEN);
    m_cmbChannel.SetCurSel(0);
    m_cmbStreamType.SetCurSel(2);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAbilityAutoDetect::OnSelchangeCmbAbilityType() 
{
	// TODO: Add your control notification handler code here
	CXmlBase xmlInput;
    m_bSTDAbility = FALSE;
    GetDlgItem(IDC_STATIC_CHANNEL)->ShowWindow(FALSE);
    GetDlgItem(IDC_STATIC_STREAM_TYPE)->ShowWindow(FALSE);
    GetDlgItem(IDC_COMBO_CHANNEL)->ShowWindow(FALSE);
    GetDlgItem(IDC_CMB_STREAM_TYPE)->ShowWindow(FALSE);
	switch (m_cmbAbilityType.GetCurSel())
	{
	case 0:	//��Ӳ������
		m_dwAbilityType = DEVICE_SOFTHARDWARE_ABILITY;
		break;
	case 1:	//Wifi����
		m_dwAbilityType = DEVICE_NETWORK_ABILITY;
		break;
	case 2: //��������
		m_dwAbilityType = DEVICE_ENCODE_ALL_ABILITY;
		break;
	case 3:	//��ǰ��������
		m_dwAbilityType = DEVICE_ENCODE_CURRENT;
		xmlInput.Parse("<CurrentCompressInfo><ChannelNumber>1</ChannelNumber><VideoEncodeType>0</VideoEncodeType><VideoResolution>3</VideoResolution></CurrentCompressInfo>");
		break;
	case 4:	//ǰ�˲�������
		m_dwAbilityType = IPC_FRONT_PARAMETER;
		break;
	case 5:	//��������
		m_dwAbilityType = FISHEYE_ABILITY;
		break;
	case 6:	//Raid����
		m_dwAbilityType = DEVICE_RAID_ABILITY;
		break;
	case 7: //��������2.0
		m_dwAbilityType = DEVICE_ENCODE_ALL_ABILITY_V20;
		xmlInput.Parse("<AudioVideoCompressInfo><AudioChannelNumber>1</AudioChannelNumber><VoiceTalkChannelNumber>1</VoiceTalkChannelNumber><VideoChannelNumber>1</VideoChannelNumber></AudioVideoCompressInfo>");
		break;
	case 8: //ǰ�β���2.0
		m_dwAbilityType = IPC_FRONT_PARAMETER_V20;
		xmlInput.Parse("<CAMERAPARA><ChannelNumber>1</ChannelNumber></CAMERAPARA>");
		break;
	case 9: //����������
		m_dwAbilityType = DECODER_ABILITY;
		xmlInput.Parse("<DecoderAbility version='2.0'></DecoderAbility>");
		break;
	case 10: //�û���������
		m_dwAbilityType = DEVICE_USER_ABILITY;
		xmlInput.Parse("<UserAbility version='2.0'></UserAbility>");
		break;
	case 11: //����Ӧ������
        m_dwAbilityType = DEVICE_NETAPP_ABILITY;
        xmlInput.Parse("<NetAppAbility version='2.0'></NetAppAbility>");
		break;
	case 12: //��Ƶͼ������
		m_dwAbilityType = DEVICE_VIDEOPIC_ABILITY;
		xmlInput.Parse("<VideoPicAbility version='2.0'>	<channelNO>1</channelNO></VideoPicAbility>");
		break;
	case 13: //JPEGץͼ����
		m_dwAbilityType = DEVICE_JPEG_CAP_ABILITY;
		xmlInput.Parse("<JpegCaptureAbility version='2.0'><channelNO>1</channelNO></JpegCaptureAbility>");
		break;
	case 14: //��������
		m_dwAbilityType = DEVICE_SERIAL_ABILITY;
		xmlInput.Parse("<SerialAbility version='2.0'></SerialAbility>");
		break;
	case 15: //��Ƶ�ۺ�ƽ̨����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 16: //������ϵͳ����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 17: //������ϵͳ����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 18: //����������ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 19: //���������ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 20: //�����ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 21: //���籨������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<AlarmHostAbility version=\"2.0\"></AlarmHostAbility>");
		break;
	case 22: //ƽ̨������ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 23: //¼���������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<RecordAbility version='2.0'></RecordAbility>");
		break;
	case 24: //�豸����ͨ������
		m_dwAbilityType = DEVICE_DYNCHAN_ABILITY;
		xmlInput.Parse("<DynChannelAbility version='2.0'><channelNO>1</channelNO></DynChanAbility>");
		break;
	case 25: //ͨ����������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<ChannelInputAbility version='2.0'><channelNO>1</channelNO></ChannelInputAbility>");
		break;
	case 26: //��Ѷ������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<InquestAbility version='2.0'></InquestAbility>");
		break;
	case 27: //CVR����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<CVRAbility version='2.0'></CVRAbility>");
		break;
	case 28: //�豸�¼�����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<EventAbility version='2.0'><channelNO>1</channelNO></EventAbility>");
		break;
	case 29: //ǰ�˽���ͨ������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<GetAccessDeviceChannelAbility version='2.0'></GetAccessDeviceChannelAbility>");
		break;
	case 30: //����Ԥ���л�����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<PreviewSwitchAbility version='2.0'></PreviewSwitchAbility>");
		break;
	case 31: //ROI����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<ROIAbility version='2.0'><channelNO>1</channelNO></ROIAbility>");
		break;
	case 32: //��̨����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<PTZAbility><channelNO>1</channelNO></PTZAbility>");
		break;
	case 33: //VQD����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<VQDAbility version='2.0'><channelNO>1</channelNO></VQDAbility>");
		break;
	case 34://���ܽ�ͨ����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<ITDeviceAbility version='2.0'><channelNO>1</channelNO></ITDeviceAbility>");
		break;
	case 35: //N+1����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<NPlusOneAbility  version='2.0'></NPlusOneAbility >");
		break;
	case 36://�����������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<HardDiskAbility version='2.0'></HardDiskAbility>");
		break;
	case 37://�豸��������
		m_dwAbilityType = DEVICE_ALARM_ABILITY;
		xmlInput.Parse("<AlarmAbility version='2.0'><channelID>1</channelID></AlarmAbility>");
		break;
	case 38://IPC�����ļ����뵼������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<IPAccessConfigFileAbility version='2.0'></IPAccessConfigFileAbility>");
		break;
	case 39://ǰ�˶�̬������ȡ���ع�ʱ�䣩
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<CameraParaDynamicAbility version='2.0'><channelNO>1</channelNO><ExposureSetDynamicLinkTo><WDR><WDREnable>0</WDREnable></WDR><IrisMode><IrisType>0</IrisType></IrisMode></ExposureSetDynamicLinkTo></CameraParaDynamicAbility>");
		break;
	case 40://ǰ�˶�̬������ȡ��CaptureMode��
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<CameraParaDynamicAbility version='2.0'><channelNO>1</channelNO><AudioVideoCompressInfoDynamicLinkTo><captureMode opt='640*480@30fps'/></AudioVideoCompressInfoDynamicLinkTo></CameraParaDynamicAbility>");
		break;
	case 41://GBT28181Э��
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<GBT28181AccessAbility version='2.0'><channelNO>1</channelNO></GBT28181AccessAbility>");
		break;
	case 42://��־��������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<SearchLogAbility version='2.0'><channelNO>1</channelNO></SearchLogAbility>");
		break;
	case 43://��������¼��
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<AlarmTriggerRecordAbility version='2.0'><channelNO>1</channelNO></AlarmTriggerRecordAbility>");
		break;
	case 44://IP���ӶԽ��ֻ�����
		m_dwAbilityType = IP_VIEW_DEV_ABILITY;
		break;
    case 45://��������
        m_dwAbilityType = MATRIX_ABILITY; 
        xmlInput.Parse("<MatrixAbility version='2.0'></MatrixAbility>"); 
        break; 
	case 46:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<IOAbility version='2.0'><channelNO>1</channelNO></IOAbility>");
		break;
	case 47:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<AccessProtocolAbility version='2.0'><channelNO>1</channelNO></AccessProtocolAbility>");
		break;
	case 48:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<VcaDevAbility version='2.0'></VcaDevAbility>");
		break;
	case 49:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<VcaCtrlAbility  version='2.0'><channelNO>1</channelNO></VcaCtrlAbility>");
		break;
	case 50:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<VcaChanAbility  version='2.0'><channelNO>1</channelNO></VcaChanAbility>");
		break;
	case 51:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<CameraMountAbility  version='2.0'><channelNO>1</channelNO></CameraMountAbility>");
		break;
	case 52:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<RecordingHostAbility version='2.0'></RecordingHostAbility>");
		break;
	case 53://˫Ŀ����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		xmlInput.Parse("<BinocularAbility  version='2.0'><channelNO>1</channelNO></BinocularAbility>");
		break;
    case 54: //Smart����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_SMART_CAPABILITIES;
        break;
    case 55: //�¼���������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_EVENT_TRIGGERS_CAPABILITIES;
        break;
    case 56: //���������������
        m_bSTDAbility = TRUE;    
        m_dwAbilityType = NET_DVR_GET_REGION_ENTRANCE_CAPABILITIES;
        m_strInputParam = "1";
        break;    
    case 57: //����������Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_REGION_ENTRANCE_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 58: //�뿪�����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_REGION_EXITINT_CAPABILITIES;
        m_strInputParam = "1";
        break;    
    case 59: //�뿪������Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_REGION_EXITING_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;    
    case 60: //�ǻ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_LOITERING_CAPABILITIES;
        m_strInputParam = "1";
        break;                
    case 61: //�ǻ���Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_LOITERING_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;                            
    case 62: //��Ա�ۼ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_GROUPDETECTION_CAPABILITIES;
        m_strInputParam = "1";
        break;                                        
    case 63: //��Ա�ۼ���Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_GROUP_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;                                                    
    case 64: //�����˶��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RAPIDMOVE_CAPABILITIES;
        m_strInputParam = "1";
        break;                                                                
    case 65: //�����˶���Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RAPIDMOVE_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;                                                                            
    case 66: //ͣ���������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PATKING_CAPABILITIES;
        m_strInputParam = "1";
        break;                                                                                        
    case 67: //ͣ����Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PARKING_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;                                                                                                    
    case 68: //��Ʒ�����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_UNATTENDED_BAGGAGE_CAPABILITIES;
        m_strInputParam = "1";
        break;                                                                                                                
    case 69: //��Ʒ������Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_UNATTENDEDBAGGAGE_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;            
    case 70: //��Ʒ��ȡ�������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_ATTENDEDBAGGAGE_CAPABILITIES;
        m_strInputParam = "1";
        break;                        
    case 71: //��Ʒ��ȡ��Ⲽ��ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_ATTENDEDBAGGAGE_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;            
    case 72: //����ü�����
        GetDlgItem(IDC_STATIC_CHANNEL)->ShowWindow(TRUE);
        GetDlgItem(IDC_STATIC_STREAM_TYPE)->ShowWindow(TRUE);
        GetDlgItem(IDC_COMBO_CHANNEL)->ShowWindow(TRUE);
        GetDlgItem(IDC_CMB_STREAM_TYPE)->ShowWindow(TRUE);
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_REGIONCLIP_CAPABILITIES;
        break;                        
    case 73: //Network����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_NETWORK_CAPABILITIES;
        break;            
    case 74: //���߲��Ų�������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_WIRELESSDIAL_CAPABILITIES;
        m_strInputParam = "1";
        break;                        
    case 75: //���żƻ�����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_WIRELESSDIAL_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 76:
        m_dwAbilityType = ACS_ABILITY;
        xmlInput.Parse("<AcsAbility version='2.0'></AcsAbility>");
		break;
    case 77:
        m_dwAbilityType = DEVICE_ABILITY_INFO;
        xmlInput.Parse("<ImageDisplayParamAbility version='2.0'><channelNO>1,2</channelNO></ImageDisplayParamAbility>");
		break;
	case 78:
		m_dwAbilityType = MERGEDEV_ABILITY;
		break; 
    case 79: //���������������
        m_bSTDAbility = TRUE;    
        m_dwAbilityType = NET_DVR_GET_REGION_ENTRANCE_CAPABILITIES;
        m_strInputParam = "1";
        break; 
    case 80:
        m_dwAbilityType = DEVICE_ABILITY_INFO;
        xmlInput.Parse("<SecurityAbility version='2.0'><channelNO>1</channelNO></SecurityAbility>");
		break;
    case 81:
        m_bSTDAbility = TRUE;    
        m_dwAbilityType = NET_DVR_GET_LITESTORAGE_CAPABILITIES;
        m_strInputParam = "1";
        break; 
    case 82:
        m_bSTDAbility = TRUE;    
        m_dwAbilityType = NET_DVR_GET_VEHICLE_CAPABILITIES;
        m_strInputParam = "1";
        break; 
    case 83:	//IPC��������
		m_dwAbilityType = IPC_UPGRADE_DESCRIPTION;
        break;
	case 84:
        m_bSTDAbility = TRUE;    
        m_dwAbilityType = NET_DVR_GET_SLAVECAMERA_CAPABILITIES;
        m_strInputParam = "1";
        break; 
    case 85:
        m_bSTDAbility = TRUE;    
        m_dwAbilityType = NET_DVR_GET_SLAVECAMERA_CALIB_CAPABILITIES;
        m_strInputParam = "1";
        break; 
	case 86:
        m_bSTDAbility = TRUE;    
        m_dwAbilityType = NET_DVR_GET_TRACKING_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 87:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_MASTERSLAVETRACKING_CAPABILITIES;
        break;
    case 88:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_DDNS_COUNTRY_ABILITY;
        break;
    case 89:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_FIREDETECTION_CAPABILITIES;
        m_strInputParam = "2";
        break;
    case 90:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_THERMAL_CAPABILITIES;
        //m_strInputParam = "";
        break;
    case 91:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_SENSOR_PORT_CAPABILITIES;
        //m_strInputParam = "";
        break;
    case 92://NVR����IPC����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_ACTIVATE_IPC_ABILITY;
        break;
    case 93://���в�������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_CENTRALIZEDCTRL_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 94://������������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_COMPASS_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 95://��Ƶ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_STREAMING_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 96://��Ƶˢ��֡����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_REFRESHFRAME_CAPABILITIES;
        m_strInputParam = "1";
        break;
	case 97:
		m_dwAbilityType = STREAM_ABILITY;
		xmlInput.Parse("<StreamAbility version='2.0'></StreamAbility>");
		break;
	case 98:
		m_dwAbilityType = ACS_ABILITY;
		xmlInput.Parse("<AcsAbility version='2.0'></AcsAbility>");
		break;
	case 99:
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_GBT28181_SERVICE_CAPABILITIES;
		break;
    case 100:
        m_dwAbilityType = DEVICE_ABILITY_INFO;
        xmlInput.Parse("<POSAbility  version='2.0'></POSAbility>");
		break;
    case 101: //�ȵ㹦����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_WIRELESSSERVER_CAPABILITIES;
        m_strInputParam = "1";
		break;
    case 102: //�����豸�б�
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_CONNECT_LIST_CAPABILITIES;
        m_strInputParam = "1";
		break;
    case 103:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RECORDING_PUBLISH_FILE_CAP;
        m_strInputParam = "1";
		break;
    case 104:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RECORD_VIDEO_CFG_CAP;
        m_strInputParam = "1";
		break;
    case 105:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RECORD_HOST_CAP;
		break;
    case 106://��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_EXTERNALDEVICE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 107://���ò��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_SUPPLEMENTLIGHT_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 108:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_LOWPOWER_CAPABILITIES;
		m_strInputParam = "1";
        break;
    case 109:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_ZOOMLINKAGE_CAPABILITIES;
		m_strInputParam = "1";
        break;
    case 110:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_ONLINEUPGRADE_ABILITY;
        break;
	case 111: //��ص�����ʾ
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_OSD_BATTERY_POWER_CFG_CAPABILITIES;
        m_strInputParam = "1";
		break;
	case 112://�ն˻�����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_CONFERENCE_REGION_CAP;
        break;
    case 113://�ն˺�����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_TERMINAL_CALL_CFG_CAP;
        break;
    case 114://�ն˺��п�������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_TERMINAL_CTRL_CAP;
        break;
    case 115://���в�ѯ����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_CALL_QUERY_CAP;
        break;
    case 116://VCS����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_VCS_CAP;
        break;
	case 117://���������������
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_TERMINAL_INPUT_CFG_CAP;
		break;
	case 118://��ʪ������Э�������
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_THSCREEN_CAPABILITIES;
		break;
    case 119://IPCȫ�����ͼƬ��������
        m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_PANORAMAIMAGE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 120://��������
        m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_STREAMENCRYPTION_CAPABILITIES;
        break;
	case 121://У׼GPS��γ������
        m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_REVISE_GPS_CAPABILITIES;
		m_strInputParam = "1";
        break;
    case 122:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_TME_CHARGERULE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 123:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PAPERCHARGEINFO_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 124:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PARKINGSAPCE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 125:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PXOFFLINE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 126:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PXMULTICTRL_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 127:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_ILLEGALCARDFILTERING_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 128:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_CHARGEACCOUNT_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 129:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_TME_CAPABILITIES;
		// m_strInputParam = "1";
        break;
    case 130:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_LEDDISPLAY_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 131:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_VOICEBROADCAST_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 132:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PAPERPRINTFORMAT_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 133:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_LOCkGATE_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 134://��ȡ������ͳ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_COUNTING_CAPABILITIES;
        m_strInputParam = "1";
        break;
    case 135: //EPTZ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_EPTZ_CFG_CAPABILITIES;
		break;
    case 136: //���ĵ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_CENTER_POINT_CFG_CAPABILITIES;
		break;
    case 137: //STD���۲�������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_FISHEYE_CAPABILITIES;
		break;
	case 138://RTMP��������
		GetDlgItem(IDC_STATIC_CHANNEL)->ShowWindow(TRUE);
        GetDlgItem(IDC_STATIC_STREAM_TYPE)->ShowWindow(TRUE);
        GetDlgItem(IDC_COMBO_CHANNEL)->ShowWindow(TRUE);
        GetDlgItem(IDC_CMB_STREAM_TYPE)->ShowWindow(TRUE);
		m_cmbStreamType.SetCurSel(0);
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RTMP_CFG_CAP;
        m_strInputParam = "1";
        break;
    case 139://ƽ�����ʶ�̬����
        m_dwAbilityType = DEVICE_ABILITY_INFO;
        xmlInput.Parse("<CameraParaDynamicAbility version='2.0'><channelNO>1</channelNO><VbrAverageCapDynamicLinkTo><streamType>main</streamType><codeType>smart264</codeType><videoQualityControlType>CBR</videoQualityControlType><vbrUpperCap>512</vbrUpperCap></VbrAverageCapDynamicLinkTo></CameraParaDynamicAbility>");
		break;
    case 140://��Ӱģʽ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_FILM_MODE_CFG_CAP;
        break;
    case 141://����������������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_DIRECTED_STRATEGY_CFG_CAP;
        break;
    case 142://����߿���������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_FRAME_CFG_CAP;
        m_strInputParam = "1";
        break;
    case 143://��ƵЧ���Ż���������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_AUDIO_EFFECTIVE_CFG_CAP;
        m_strInputParam = "1";
        break;
    case 144://¼����Ƶ������������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RECORD_VIDEO_CFG_CAP;
        break;
    case 145://����ͼƬ��Ϊ����ͼƬ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_BACKGROUND_PIC_INFO_CAP;
        break;
	case 146:
		m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_LLDP_CAP;
		m_strInputParam = "1";
		break;
    case 147:
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_PORT_REMARKS_CAP;
		m_strInputParam = "1";
		break;
    case 148://�ƴ洢������
        m_dwAbilityType = 0xffffffff;
        m_bSTDAbility = 2; //͸���ӿ�,NET_DVR_STDXMLConfig
        m_strInputParam = "GET /ISAPI/ContentMgmt/CloudStorageServer/capabilities";
        break;
	case 149://LED����
		m_dwAbilityType = LED_ABILITY;
		xmlInput.Parse("<LedAbility  version='2.0'></LedAbility>");
		break;
    case 150://����ץ�Ĳ���ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_FACECAPTURE_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
		break;
    case 151://Smart��������ʱ������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_STORAGEDETECTION_SCHEDULE_CAPABILITIES;
        m_strInputParam = "1";
		break;
    case 152://Smart��д����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_STORAGEDETECTION_RWLOCK_CAPABILITIES;
        m_strInputParam = "1";
		break;

    case 153://��ȡSensor ���ڲ�����Э�������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_SENSOR_ADJUSTMENT_CAPABILITIES;
        break;
    case 154:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_MANUALRANGING_CAPABILITIES;
        m_strInputParam = "2";
        break;
    case 155://SD��������������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_STORAGEDETECTION_UNLOCK_CAPABILITIES;
		break;
	case 156: //��Ļ����������
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_SCREEN_CONFIG_CAP;
		m_strInputParam = "1";
		break;
	case 157: //��Ļ��������
		m_dwAbilityType = SCREEN_EXCHANGE_ABILITY;
		xmlInput.Parse("<ScreenExchangeAbility version=\"2.0\"></ScreenExchangeAbility>");
		break;

	case 158: //��Ļ��������½��������
		m_dwAbilityType = 0xffffffff;
        m_bSTDAbility = 2; //͸���ӿڣ�NET_DVR_STDXMLConfig
        m_strInputParam = "GET /ISAPI/DisplayDev/Auxiliary/ScreenServer/<ID>/loginCfg/abilities\r\n";
		break;
    case 159: //ͼ���ּ����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_IMAGE_DIFF_DETECTION_CFG_CAP;
        m_strInputParam = "5";
        break;
    case 160: //�����ļ���Ϣ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_RECORDING_PUBLISH_FILE_INFO_CAP;
        m_strInputParam = "1";
        break;        
    case 161: //�ֶ��γ�¼���������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_MANUAL_CURRICULUM_CONTROL_CAP;
		break;
    case 162: //����������Ϣ����
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_TMEVOICE_CAPABILITIES;
        m_strInputParam = "1";
		break;
	case 163://ftp�ϴ���Ϣ��������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_FTP_CAPABILITIES;
		break;
    case 164://��ȡptz�����������
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_PTZ_CAPABILITIES;
        m_strInputParam = "1";
		break;
    case 165:
        m_bSTDAbility = TRUE;
        m_dwAbilityType = NET_DVR_GET_POSTRADAR_CAPABILITIES;
        m_strInputParam = "1";
		break;
	case 166://�ƴ洢URL����
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_CLOUD_URL_CAP;
		break;
	case 167://�ƴ洢��������
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_CLOUD_CFG_CAP;
		break;
	case 168://�ƴ洢�ϴ�������������
		m_bSTDAbility = TRUE;
		m_dwAbilityType = NET_DVR_GET_CLOUDSTORAGE_UPLOADSTRATEGY_CAP;
		m_strInputParam = "1";
		break;
    default:
		m_dwAbilityType = 0;
		break;
	}
    if (!m_bSTDAbility)
    {
        xmlInput.SetRoot();
        m_strInputParam = xmlInput.GetChildren().c_str();
        m_strInputParam.Replace("\n", "\r\n");
    }	
	UpdateData(FALSE);
}

void CDlgAbilityAutoDetect::ParseAbility()
{
	CXmlBase xmlAll;
	char szPath[MAX_PATH] = {0};
	GetCurrentPath(szPath);
	sprintf(szPath, "%s\\SDK_ABILITY.xml", szPath);
	if(!xmlAll.LoadFile(szPath))
	{
		GetDlgItem(IDC_EDT_ABILITY_LOST)->SetWindowText("�����ļ����ش���");
		return;
	}
	xmlAll.SetRoot();
	xmlAll.IntoElem();

	switch (m_cmbAbilityType.GetCurSel())
	{
	case 0:	//��Ӳ������
		m_dwAbilityType = DEVICE_SOFTHARDWARE_ABILITY;
		ParseSimpleAbility(xmlAll, "BasicCapability");
		break;
	case 1:	//Wifi����
		m_dwAbilityType = DEVICE_NETWORK_ABILITY;
		ParseSimpleAbility(xmlAll, "NetworkSetting");
		break;
	case 2: //��������
		m_dwAbilityType = DEVICE_ENCODE_ALL_ABILITY;
		break;
	case 3:	//��ǰ��������
		m_dwAbilityType = DEVICE_ENCODE_CURRENT;
		break;
	case 4:	//ǰ�˲�������
		m_dwAbilityType = IPC_FRONT_PARAMETER;
		break;
	case 5:	//��������
		m_dwAbilityType = FISHEYE_ABILITY;
		break;
	case 6:	//Raid����
		m_dwAbilityType = DEVICE_RAID_ABILITY;
		ParseSimpleAbility(xmlAll, "RAID");
		break;
	case 7: //��������2.0
		m_dwAbilityType = DEVICE_ENCODE_ALL_ABILITY_V20;
		ParseSimpleAbility(xmlAll, "AudioVideoCompressInfo");
		break;
	case 8: //ǰ�β���2.0
		m_dwAbilityType = IPC_FRONT_PARAMETER_V20;
		ParseSimpleAbility(xmlAll, "CAMERAPARA");
		break;
	case 9: //����������
		m_dwAbilityType = DECODER_ABILITY;
		ParseSimpleAbility(xmlAll, "DecoderAbility");
		break;
	case 10: //�û���������
		m_dwAbilityType = DEVICE_USER_ABILITY;
		ParseSimpleAbility(xmlAll, "UserAbility");
		break;
	case 11: //����Ӧ������
		m_dwAbilityType = DEVICE_NETAPP_ABILITY;
		ParseSimpleAbility(xmlAll, "NetAppAbility");
		break;
	case 12: //��Ƶͼ������
		m_dwAbilityType = DEVICE_VIDEOPIC_ABILITY;
		ParseSimpleAbility(xmlAll, "VideoPicAbility");
		break;
	case 13: //JPEGץͼ����
		m_dwAbilityType = DEVICE_JPEG_CAP_ABILITY;
		ParseSimpleAbility(xmlAll, "JpegCaptureAbility");
		break;
	case 14: //��������
		m_dwAbilityType = DEVICE_SERIAL_ABILITY;
		ParseSimpleAbility(xmlAll, "SerialAbility");
		break;
	case 15: //��Ƶ�ۺ�ƽ̨����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 16: //������ϵͳ����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 17: //������ϵͳ����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 18: //����������ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 19: //���������ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 20: //�����ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 21: //���籨������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "AlarmHostAbility");
		break;
	case 22: //ƽ̨������ϵͳ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		break;
	case 23:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "RecordAbility");
		break;
	case 24:
		m_dwAbilityType = DEVICE_DYNCHAN_ABILITY;
		ParseSimpleAbility(xmlAll, "DynChannelAbility");
		break;
	case 25:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "ChannelInputAbility");
		break;
	case 26: //��Ѷ������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "InquestAbility");
		break;
	case 27: //CVR����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "CVRAbility");
		break;
	case 28: //�豸�¼�����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "EventAbility");
		break;
	case 29: //ǰ�˽���ͨ������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "GetAccessDeviceChannelAbility");
		break;
	case 30: //����Ԥ���л�����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "PreviewSwitchAbility ");
		break;
	case 31: //ROI����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "ROIAbility");
		break;
	case 32: //��̨����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "PTZAbility");
		break;
	case 33: //VQD����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "VQDAbility");
		break;
	case 34://���ܽ�ͨ
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "ITDeviceAbility");
		break;
	case 35: //N+1����
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "NPlusOneAbility");
		break;
	case 36://�����������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "HardDiskAbility");
		break;
	case 37://�豸��������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "DeviceAlarmAbility");
		break;
	case 38://IPC�����ļ����뵼������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "IPAccessConfigFileAbility");
		break;
	case 39://ǰ�˶�̬������ȡ���ع�ʱ�䣩
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "ExposureSetDynamicAbility");
		//xmlInput.Parse("<CameraParaDynamicAbility version='2.0'><channelNO>1</channelNO><ExposureSetDynamicLinkTo><WDR><WDREnable>0</WDREnable></WRD><IrisMode><IrisType>0</IrisType></IrisMode></ExposureSetDynamicLinkTo></CameraParaDynamicAbility>");
		break;
	case 40://ǰ�˶�̬������ȡ��CaptureMode��
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "CaptureModeDynamicAbility");
		//xmlInput.Parse("<CameraParaDynamicAbility version='2.0'><channelNO>1</channelNO><AudioVideoCompressInfoDynamicLinkTo><captureMode opt='640*480@30fps'/></AudioVideoCompressInfoDynamicLinkTo></CameraParaDynamicAbility>");
		break;
	case 41://GBT28181Э��
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "GBT28181AccessAbility");
		//xmlInput.Parse("<GBT28181AccessAbility version='2.0'><channelNO>1</channelNO></GBT28181AccessAbility>");
		break;
	case 42://��־��������
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "SearchLogAbility");
		//xmlInput.Parse("<SearchLogAbility version='2.0'><channelNO>1</channelNO></SearchLogAbility>");
		break;
	case 43://��������¼��
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "AlarmTriggerRecordAbility");
		//xmlInput.Parse("<AlarmTriggerRecordAbility version='2.0'><channelNO>1</channelNO></AlarmTriggerRecordAbility>");
		break;
	case 44:
		m_dwAbilityType = IP_VIEW_DEV_ABILITY;
		ParseSimpleAbility(xmlAll, "IpViewDevAbility");
		break;
	case 48:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "VcaDevAbility");
		break;
	case 49:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "VcaCtrlAbility");
		break;
	case 50:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "VcaChanAbility");
		break;
	case 51:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "CameraMountAbility");
		break;
	case 53:
		m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "BinocularAbility");
		break;
    case 76:
        m_dwAbilityType = ACS_ABILITY;
        ParseSimpleAbility(xmlAll, "AcsAbility");
		break;
    case 77:
        m_dwAbilityType = DEVICE_ABILITY_INFO;
        ParseSimpleAbility(xmlAll, "ImageDisplayParamAbility");
		break;
	case 78:
		m_dwAbilityType = MERGEDEV_ABILITY;
		break; 
    case 79:
        m_dwAbilityType = DEVICE_ABILITY_INFO;
        ParseSimpleAbility(xmlAll, "SecurityAbility");
		break;
    case 82:	//IPC��������
		m_dwAbilityType = IPC_UPGRADE_DESCRIPTION;
        break;
	case 97:
		m_dwAbilityType = STREAM_ABILITY;
		ParseSimpleAbility(xmlAll, "StreamAbility");
		break;
	case 98:
		m_dwAbilityType = ACS_ABILITY;
		ParseSimpleAbility(xmlAll, "AcsAbility");
		break;
    case 100:
        m_dwAbilityType = DEVICE_ABILITY_INFO;
		ParseSimpleAbility(xmlAll, "POSAbility");
        break;
	default:
		m_dwAbilityType = 0;
		break;
	}
}

void CDlgAbilityAutoDetect::ParseSimpleAbility(CXmlBase &xmlAll, char* szAbilityName)
{	
	CXmlBase xmlDev;
	
	if (!xmlAll.FindElem(szAbilityName))
	{
		GetDlgItem(IDC_EDT_ABILITY_LOST)->SetWindowText("�����ļ���û�е�ǰ����");
		return ;
	}
	xmlAll.Parse(xmlAll.GetChildren().c_str());
	xmlAll.SetRoot();
	
	xmlDev.Parse(m_pOutBuf);
	if (!xmlDev.FindElem(szAbilityName))
	{
		GetDlgItem(IDC_EDT_ABILITY_LOST)->SetWindowText("���ݸ�ʽ����,�޷�����");
		return ;
	}

	ParseAbilityRecursive(xmlAll, xmlDev);

	UpdateData(FALSE);
}

void CDlgAbilityAutoDetect::ParseAbilityRecursive(CXmlBase &xmlAll, CXmlBase &xmlDev)
{
 	string strNode = xmlAll.GetNodeName();
 
 	if (!xmlDev.FindElem(strNode.c_str()))
 	{
 		m_strLostAbility += "LOST:";
		m_strLostAbility += strNode.c_str();
 		m_strLostAbility += "\r\n";
		if (xmlAll.NextSibElem())
		{
			ParseAbilityRecursive(xmlAll, xmlDev);
		}
		return;
 	}
 	
 	if (xmlAll.IntoElem())
	{
		if(xmlDev.IntoElem())
		{
			ParseAbilityRecursive(xmlAll, xmlDev);
			xmlDev.OutOfElem();
		}
		else
		{
			if (xmlDev.GetNodeName() == strNode && xmlDev.GetData() == "" && xmlDev.GetFirstAttributeValue() == "")
			{
				m_strLostAbility += "NULL:";
				m_strLostAbility += xmlDev.GetNodeName().c_str();
				m_strLostAbility += "\r\n";
			}			
			ParseAbilityRecursive(xmlAll, xmlDev);
		}
		xmlAll.OutOfElem();
	}
	else if (xmlDev.GetNodeName() == strNode && xmlDev.GetData() == "" && xmlDev.GetFirstAttributeValue() == "")
	{
		m_strLostAbility += "NULL:";
		m_strLostAbility += xmlDev.GetNodeName().c_str();
		m_strLostAbility += "\r\n";
	}

	if (xmlAll.NextSibElem())
	{
		if (!xmlDev.NextSibElem())	//������ж���Ϊ�˴�����ͬ���ƽڵ���ڶ�������
		{
			do 
			{
				m_strLostAbility += "LOST:";
				m_strLostAbility += xmlAll.GetNodeName().c_str();
 				m_strLostAbility += "\r\n";
			} while (xmlAll.NextSibElem());
			return;
		}
		ParseAbilityRecursive(xmlAll, xmlDev);
	}
}

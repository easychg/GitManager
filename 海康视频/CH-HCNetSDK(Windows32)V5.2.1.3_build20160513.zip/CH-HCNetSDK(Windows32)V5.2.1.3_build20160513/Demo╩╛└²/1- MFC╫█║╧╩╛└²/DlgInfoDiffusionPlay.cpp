// DlgInfoDiffusionPlay.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgInfoDiffusionPlay.h"

#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInfoDiffusionPlay dialog


CDlgInfoDiffusionPlay::CDlgInfoDiffusionPlay(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInfoDiffusionPlay::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInfoDiffusionPlay)
	m_dwTerminalID = 0;
	m_dwProgramID = 0;
	m_dwProgramDuration = 0;
	m_dwPrtScnID = 0;
	m_dwMaterialID = 0;
	m_dwPlayCount = 0;
	m_dwPositionHeight = 0;
	m_dwPositionWidth = 0;
	m_dwPositionX = 0;
	m_dwPositionY = 0;
	//}}AFX_DATA_INIT
	m_iDeviceIndex = g_pMainDlg->GetCurDeviceIndex();
	m_lUserID = g_struDeviceInfo[m_iDeviceIndex].lLoginID;
	m_nCurSelTerminal = -1;
	m_pOutputXmlBuffer = new char[MAX_LEN_XML];
	memset(m_pOutputXmlBuffer, 0, sizeof(char)*MAX_LEN_XML);
	m_pImageBuffer = NULL;
	m_lpControl = new NET_DVR_PLAY_CONTROL;
	memset(m_lpControl, 0, sizeof(*m_lpControl));
	m_lpControl->dwSize = sizeof(*m_lpControl);
}


void CDlgInfoDiffusionPlay::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInfoDiffusionPlay)
	DDX_Control(pDX, IDC_COMBO_PLAY_MODE, m_cmbPlayMode);
	DDX_Control(pDX, IDC_COMBO_CTRL_TYPE, m_cmbCtrlType);
	DDX_Control(pDX, IDC_COMBO_INSERT_TYPE, m_cmbInsertType);
	DDX_Control(pDX, IDC_COMBO_TARGET_TYPE, m_cmbTargetType);
	DDX_Control(pDX, IDC_LIST_TERMINAL, m_listTerminal);
	DDX_Text(pDX, IDC_EDIT_TERMINAL_ID, m_dwTerminalID);
	DDX_Text(pDX, IDC_EDIT_PROGRAM_ID, m_dwProgramID);
	DDX_Text(pDX, IDC_EDIT_PROGRAM_DURATION, m_dwProgramDuration);
	DDX_Text(pDX, IDC_EDIT_PRTSCN_ID, m_dwPrtScnID);
	DDX_Text(pDX, IDC_EDIT_MATERIAL_ID, m_dwMaterialID);
	DDX_Text(pDX, IDC_EDIT_PLAY_COUNT, m_dwPlayCount);
	DDX_Text(pDX, IDC_EDIT_POSITION_HEIGHT, m_dwPositionHeight);
	DDX_Text(pDX, IDC_EDIT_POSITION_WIDTH, m_dwPositionWidth);
	DDX_Text(pDX, IDC_EDIT_POSITION_X, m_dwPositionX);
	DDX_Text(pDX, IDC_EDIT_POSITION_Y, m_dwPositionY);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInfoDiffusionPlay, CDialog)
	//{{AFX_MSG_MAP(CDlgInfoDiffusionPlay)
	ON_CBN_SELCHANGE(IDC_COMBO_CTRL_TYPE, OnSelchangeComboCtrlType)
	ON_CBN_SELCHANGE(IDC_COMBO_INSERT_TYPE, OnSelchangeComboInsertType)
	ON_CBN_SELCHANGE(IDC_COMBO_TARGET_TYPE, OnSelchangeComboTargetType)
	ON_BN_CLICKED(IDC_BTN_ADD, OnBtnAdd)
	ON_BN_CLICKED(IDC_BTN_CONTROL, OnBtnControl)
	ON_BN_CLICKED(IDC_BTN_DEL, OnBtnDel)
	ON_BN_CLICKED(IDC_BTN_EXIT, OnBtnExit)
	ON_BN_CLICKED(IDC_BTN_MOD, OnBtnMod)
	ON_BN_CLICKED(IDC_BTN_PRTSCN, OnBtnPrtscn)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_LIST_TERMINAL, OnClickListTerminal)
	ON_CBN_SELCHANGE(IDC_COMBO_PLAY_MODE, OnSelchangeComboPlayMode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInfoDiffusionPlay message handlers

BOOL CDlgInfoDiffusionPlay::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitTerminalCtrlList();
	m_cmbCtrlType.SetCurSel(0);
	OnSelchangeComboCtrlType();
	m_cmbTargetType.SetCurSel(0);
	OnSelchangeComboTargetType();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgInfoDiffusionPlay::OnSelchangeComboCtrlType() 
{
	// TODO: Add your control notification handler code here
	int nSel = m_cmbCtrlType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	CString strCtrlType;
	m_cmbCtrlType.GetLBText(nSel, strCtrlType);
	if (0 == strcmp(strCtrlType, "insert"))
	{
		GetDlgItem(IDC_COMBO_INSERT_TYPE)->EnableWindow(TRUE);
		m_cmbInsertType.SetCurSel(0);
		OnSelchangeComboInsertType();
	}
	else
	{
		GetDlgItem(IDC_COMBO_INSERT_TYPE)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_MATERIAL_ID)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROGRAM_ID)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_PLAY_MODE)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PLAY_COUNT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROGRAM_DURATION)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_POSITION_X)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_POSITION_Y)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_POSITION_WIDTH)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_POSITION_HEIGHT)->EnableWindow(FALSE);
	}
}

void CDlgInfoDiffusionPlay::OnSelchangeComboInsertType() 
{
	// TODO: Add your control notification handler code here
	int nSel = m_cmbInsertType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	CString strInsertType;
	m_cmbInsertType.GetLBText(nSel, strInsertType);
	if (0 == strcmp(strInsertType, "material"))
	{
		GetDlgItem(IDC_EDIT_MATERIAL_ID)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_PROGRAM_ID)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_PLAY_MODE)->EnableWindow(TRUE);
		m_cmbPlayMode.SetCurSel(0);
		OnSelchangeComboPlayMode();
		GetDlgItem(IDC_EDIT_POSITION_X)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_POSITION_Y)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_POSITION_WIDTH)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_POSITION_HEIGHT)->EnableWindow(TRUE);
	}
	else if (0 == strcmp(strInsertType, "program"))
	{
		GetDlgItem(IDC_EDIT_MATERIAL_ID)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROGRAM_ID)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_PLAY_MODE)->EnableWindow(TRUE);
		m_cmbPlayMode.SetCurSel(0);
		OnSelchangeComboPlayMode();
		GetDlgItem(IDC_EDIT_POSITION_X)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_POSITION_Y)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_POSITION_WIDTH)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_POSITION_HEIGHT)->EnableWindow(TRUE);
	}
}

void CDlgInfoDiffusionPlay::OnSelchangeComboTargetType() 
{
	// TODO: Add your control notification handler code here
	int nSel = m_cmbTargetType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	CString strTargetType;
	m_cmbTargetType.GetLBText(nSel, strTargetType);
	if (0 == strcmp(strTargetType, "terminals"))
	{
		char szLan[512] = {0};
		g_StringLanType(szLan, "�ն˱��", "Terminal No.");
		GetDlgItem(IDC_STAT_TERMINAL_ID)->SetWindowText(szLan);
	}
	else if (0 == strcmp(strTargetType, "terminalGroups"))
	{
		char szLan[512] = {0};
		g_StringLanType(szLan, "�ն�����", "Group No.");
		GetDlgItem(IDC_STAT_TERMINAL_ID)->SetWindowText(szLan);
	}
	RefreshTernimalList(strTargetType);
}

void CDlgInfoDiffusionPlay::InitTerminalCtrlList()
{
	DWORD dwExStyle = m_listTerminal.GetExtendedStyle();
	dwExStyle |= LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES;
	m_listTerminal.SetExtendedStyle(dwExStyle);
	
	char szLan[512] = {0};
	g_StringLanType(szLan, "���", "Index");
	m_listTerminal.InsertColumn(0, szLan);
	m_listTerminal.SetColumnWidth(0, 60);
	
	memset(szLan, 0, sizeof(szLan));
	g_StringLanType(szLan, "���", "Number");
	m_listTerminal.InsertColumn(1, szLan);
	m_listTerminal.SetColumnWidth(1, 100);
}

void CDlgInfoDiffusionPlay::RefreshTernimalList(CString strTargetType)
{
	m_listTerminal.DeleteAllItems();
	CString str;
	if (0 == strcmp(strTargetType, "terminals"))
	{
		for (int nTerCnt = 0; nTerCnt < m_lpControl->dwTerminalCount; nTerCnt++)
		{
			str.Format("%d", nTerCnt+1);
			m_listTerminal.InsertItem(nTerCnt, str);
			str.Format("%d", m_lpControl->dwTerminalList[nTerCnt]);
			m_listTerminal.SetItemText(nTerCnt, 1, str);
		}
	}
	else if (0 == strcmp(strTargetType, "terminalGroups"))
	{
		for (int nGrpCnt = 0; nGrpCnt < m_lpControl->dwGroupCount; nGrpCnt++)
		{
			str.Format("%d", nGrpCnt+1);
			m_listTerminal.InsertItem(nGrpCnt, str);
			str.Format("%d", m_lpControl->dwTerminalGroupList[nGrpCnt]);
			m_listTerminal.SetItemText(nGrpCnt, 1, str);
		}
	}
}

void CDlgInfoDiffusionPlay::OnBtnAdd() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	int nSel = m_cmbTargetType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	CString strTargetType;
	m_cmbTargetType.GetLBText(nSel, strTargetType);
	int nIndex = m_listTerminal.GetItemCount();
	if (0 == strcmp(strTargetType, "terminals"))
	{
		m_lpControl->dwTerminalList[nIndex] = m_dwTerminalID;
		m_lpControl->dwTerminalCount++;
	}
	else if (0 == strcmp(strTargetType, "terminalGroups"))
	{
		m_lpControl->dwTerminalGroupList[nIndex] = m_dwTerminalID;
		m_lpControl->dwGroupCount++;
	}
	CString str;
	str.Format("%d", nIndex+1);
	m_listTerminal.InsertItem(nIndex, str);
	m_listTerminal.SetItemState(m_nCurSelTerminal, 0, -1);
	m_listTerminal.SetItemState(nIndex, LVIS_SELECTED, LVIS_SELECTED);
	m_listTerminal.SetFocus();
	m_nCurSelTerminal = nIndex;
	str.Format("%d", m_dwTerminalID);
	m_listTerminal.SetItemText(nIndex, 1, str);
}

void CDlgInfoDiffusionPlay::OnBtnControl() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	int nSel = m_cmbCtrlType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	m_cmbCtrlType.GetLBText(nSel, m_lpControl->szControlType);
	nSel = m_cmbTargetType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	m_cmbTargetType.GetLBText(nSel, m_lpControl->szTargetType);
	if (0 == strcmp(m_lpControl->szControlType, "insert"))
	{
		nSel = m_cmbInsertType.GetCurSel();
		if (nSel == CB_ERR)
		{
			char szLan1[512] = {0};
			char szLan2[512] = {0};
			g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
			g_StringLanType(szLan2, "���ſ���", "Play Control");
			MessageBox(szLan1, szLan2, MB_ICONWARNING);
			return;
		}
		m_cmbInsertType.GetLBText(nSel, m_lpControl->struInsertInfo.szInsertType);
		if (0 == strcmp(m_lpControl->struInsertInfo.szInsertType, "material"))
		{
			m_lpControl->struInsertInfo.dwMaterialID = m_dwMaterialID;
			nSel = m_cmbPlayMode.GetCurSel();
			if (nSel == CB_ERR)
			{
				char szLan1[512] = {0};
				char szLan2[512] = {0};
				g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
				g_StringLanType(szLan2, "���ſ���", "Play Control");
				MessageBox(szLan1, szLan2, MB_ICONWARNING);
				return;
			}
			m_cmbPlayMode.GetLBText(nSel, m_lpControl->struInsertInfo.szPlayMode);
			if (0 == strcmp(m_lpControl->struInsertInfo.szPlayMode, "byTime"))
			{
				m_lpControl->struInsertInfo.dwDuration = m_dwProgramDuration;
			}
			else if (0 == strcmp(m_lpControl->struInsertInfo.szPlayMode, "byCount"))
			{
				m_lpControl->struInsertInfo.dwCount = m_dwPlayCount;
			}
			m_lpControl->struInsertInfo.dwPositionX = m_dwPositionX;
			m_lpControl->struInsertInfo.dwPositionY = m_dwPositionY;
			m_lpControl->struInsertInfo.dwPositionWidth = m_dwPositionWidth;
			m_lpControl->struInsertInfo.dwPostionHeight = m_dwPositionHeight;
		}
		else if (0 == strcmp(m_lpControl->struInsertInfo.szInsertType, "program"))
		{
			m_lpControl->struInsertInfo.dwProgramID = m_dwProgramID;
			nSel = m_cmbPlayMode.GetCurSel();
			if (nSel == CB_ERR)
			{
				char szLan1[512] = {0};
				char szLan2[512] = {0};
				g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
				g_StringLanType(szLan2, "���ſ���", "Play Control");
				MessageBox(szLan1, szLan2, MB_ICONWARNING);
				return;
			}
			m_cmbPlayMode.GetLBText(nSel, m_lpControl->struInsertInfo.szPlayMode);
			if (0 == strcmp(m_lpControl->struInsertInfo.szPlayMode, "byTime"))
			{
				m_lpControl->struInsertInfo.dwDuration = m_dwProgramDuration;
			}
			else if (0 == strcmp(m_lpControl->struInsertInfo.szPlayMode, "byCount"))
			{
				m_lpControl->struInsertInfo.dwCount = m_dwPlayCount;
			}
			m_lpControl->struInsertInfo.dwPositionX = m_dwPositionX;
			m_lpControl->struInsertInfo.dwPositionY = m_dwPositionY;
			m_lpControl->struInsertInfo.dwPositionWidth = m_dwPositionWidth;
			m_lpControl->struInsertInfo.dwPostionHeight = m_dwPositionHeight;
		}
	}
	
	char* pInputBuff = NULL;
	DWORD dwInputSize = 0;
	ConvertPlayControlParamsStruToXml(m_lpControl, &pInputBuff, dwInputSize);
	
	CString strCommand;
	strCommand.Format("PUT /ISAPI/Publish/TerminalMgr/terminals/control\r\n");
	NET_DVR_XML_CONFIG_INPUT struInputParam = {0};
	struInputParam.dwSize = sizeof(struInputParam);
	struInputParam.lpRequestUrl = strCommand.GetBuffer(0);
	struInputParam.dwRequestUrlLen = strCommand.GetLength();
	struInputParam.lpInBuffer = pInputBuff;
	struInputParam.dwInBufferSize = dwInputSize;
	
	char szStatusBuff[1024] = {0};
	NET_DVR_XML_CONFIG_OUTPUT struOutputParam = {0};
	struOutputParam.dwSize = sizeof(struOutputParam);
	struOutputParam.lpStatusBuffer = szStatusBuff;
	struOutputParam.dwStatusSize = sizeof(szStatusBuff);
	
	if (!NET_DVR_STDXMLConfig(m_lUserID, &struInputParam, &struOutputParam))
	{
		g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_FAIL_T, "NET_DVR_STDXMLConfig");
		delete[] pInputBuff;
		pInputBuff = NULL;
		return;
	}
	g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_SUCC_T, "NET_DVR_STDXMLConfig");
	
	delete[] pInputBuff;
	pInputBuff = NULL;
	
	UpdateData(FALSE);
}

void CDlgInfoDiffusionPlay::OnBtnDel() 
{
	// TODO: Add your control notification handler code here
	if (m_nCurSelTerminal < 0)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "��ѡ���ն�/�ն���", "Please choose a terminal/group first.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	
	int nSel = m_cmbTargetType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	CString strTargetType;
	m_cmbTargetType.GetLBText(nSel, strTargetType);
	if (0 == strcmp(strTargetType, "terminals"))
	{
		for (int nTerCnt = m_nCurSelTerminal; nTerCnt < m_listTerminal.GetItemCount()-1; nTerCnt++)
		{
			m_listTerminal.SetItemText(nTerCnt, 1, m_listTerminal.GetItemText(nTerCnt+1, 1));
			m_lpControl->dwTerminalList[nTerCnt] = m_lpControl->dwTerminalList[nTerCnt+1];
		}
		m_lpControl->dwTerminalList[m_listTerminal.GetItemCount()-1] = 0;
		m_lpControl->dwTerminalCount--; //����-1;
	}
	else if (0 == strcmp(strTargetType, "terminalGroups"))
	{
		for (int nGrpCnt = m_nCurSelTerminal; nGrpCnt < m_listTerminal.GetItemCount()-1; nGrpCnt++)
		{
			m_listTerminal.SetItemText(nGrpCnt, 1, m_listTerminal.GetItemText(nGrpCnt+1, 1));
			m_lpControl->dwTerminalGroupList[nGrpCnt] = m_lpControl->dwTerminalGroupList[nGrpCnt+1];
		}
		m_lpControl->dwTerminalGroupList[m_listTerminal.GetItemCount()-1] = 0;
		m_lpControl->dwGroupCount--; //����-1;
	}
	m_listTerminal.DeleteItem(m_listTerminal.GetItemCount()-1);
	m_nCurSelTerminal = -1;
}

void CDlgInfoDiffusionPlay::OnBtnExit() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void CDlgInfoDiffusionPlay::OnBtnMod() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	if (m_nCurSelTerminal < 0)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "��ѡ���ն�/�ն���", "Please choose a terminal/group first.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	
	int nSel = m_cmbTargetType.GetCurSel();
	if (nSel == CB_ERR)
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		return;
	}
	CString strTargetType;
	m_cmbTargetType.GetLBText(nSel, strTargetType);
	if (0 == strcmp(strTargetType, "byTerminal"))
	{
		m_lpControl->dwTerminalList[m_nCurSelTerminal] = m_dwTerminalID;
	}
	else if (0 == strcmp(strTargetType, "byGroup"))
	{
		m_lpControl->dwTerminalGroupList[m_nCurSelTerminal] = m_dwTerminalID;
	}
	CString str;
	str.Format("%d", m_dwTerminalID);
	m_listTerminal.SetItemText(m_nCurSelTerminal, 1, str);
}

void CDlgInfoDiffusionPlay::OnBtnPrtscn() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	CString strCommand;
	strCommand.Format("GET /ISAPI/Publish/TerminalMgr/screenShot/%d\r\n", m_dwPrtScnID);
	NET_DVR_XML_CONFIG_INPUT struInputParam = {0};
	struInputParam.dwSize = sizeof(struInputParam);
	struInputParam.lpRequestUrl = strCommand.GetBuffer(0);
	struInputParam.dwRequestUrlLen = strCommand.GetLength();
	
	m_pImageBuffer = new char[IMAGE_BUFFER];
	memset(m_pImageBuffer, 0, sizeof(char)*IMAGE_BUFFER);

	char szStatusBuff[1024] = {0};
	NET_DVR_XML_CONFIG_OUTPUT struOutputParam = {0};
	struOutputParam.dwSize = sizeof(struOutputParam);
	memset(m_pImageBuffer, 0, IMAGE_BUFFER);
	struOutputParam.lpOutBuffer = m_pImageBuffer;
	struOutputParam.dwOutBufferSize = IMAGE_BUFFER;
	struOutputParam.lpStatusBuffer = szStatusBuff;
	struOutputParam.dwStatusSize = sizeof(szStatusBuff);
	
	if (!NET_DVR_STDXMLConfig(m_lUserID, &struInputParam, &struOutputParam))
	{
		g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_FAIL_T, "NET_DVR_STDXMLConfig");
		delete[] m_pImageBuffer;
		m_pImageBuffer = NULL;
		return;
	}
	g_pMainDlg->AddLog(m_iDeviceIndex, OPERATION_SUCC_T, "NET_DVR_STDXMLConfig");
	
	CString strImageFilePath;
	strImageFilePath.Format("C:\\Picture");
	if (!PathFileExists(strImageFilePath))
	{
		if (!CreateDirectory(strImageFilePath, NULL))
		{
			char szLan1[512] = {0};
			char szLan2[512] = {0};
			g_StringLanType(szLan1, "����Ŀ¼ʧ��", "Create directory failed.");
			g_StringLanType(szLan2, "���ſ���", "Play Control");
			MessageBox(szLan1, szLan2, MB_ICONWARNING);
			delete[] m_pImageBuffer;
		    m_pImageBuffer = NULL;
			return;
		}
	}
	CTime time(NULL);
	strImageFilePath.Format("C:\\Picture\\%d%02d%02d%02d%02d%02d.jpg",
		time.GetYear(), time.GetMonth(), time.GetDay(), time.GetHour(), time.GetMinute(), time.GetSecond());
	CFile file;
	if (!file.Open(strImageFilePath, CFile::modeCreate|CFile::modeWrite))
	{
		char szLan1[512] = {0};
		char szLan2[512] = {0};
		g_StringLanType(szLan1, "�����ļ�ʧ��", "Create file failed.");
		g_StringLanType(szLan2, "���ſ���", "Play Control");
		MessageBox(szLan1, szLan2, MB_ICONWARNING);
		delete[] m_pImageBuffer;
		m_pImageBuffer = NULL;
		return;
	}
	file.Write(m_pImageBuffer, IMAGE_BUFFER);
	file.Close();
}

void CDlgInfoDiffusionPlay::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	delete m_lpControl;
	m_lpControl = NULL;
	delete[] m_pOutputXmlBuffer;
	m_pOutputXmlBuffer = NULL;
}

void CDlgInfoDiffusionPlay::OnClickListTerminal(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	POSITION pos = m_listTerminal.GetFirstSelectedItemPosition();
	if (pos)
	{
		m_nCurSelTerminal = m_listTerminal.GetNextSelectedItem(pos);
		int nSel = m_cmbTargetType.GetCurSel();
		if (nSel == CB_ERR)
		{
			char szLan1[512] = {0};
			char szLan2[512] = {0};
			g_StringLanType(szLan1, "�������������", "Input parameters is not enough.");
			g_StringLanType(szLan2, "���ſ���", "Play Control");
			MessageBox(szLan1, szLan2, MB_ICONWARNING);
			return;
		}
		CString strTargetType;
		m_cmbTargetType.GetLBText(nSel, strTargetType);
		if (0 == strcmp(strTargetType, "terminals"))
		{
			m_dwTerminalID = m_lpControl->dwTerminalList[m_nCurSelTerminal];
		}
		else if (0 == strcmp(strTargetType, "terminalGroups"))
		{
			m_dwTerminalID = m_lpControl->dwTerminalGroupList[m_nCurSelTerminal];
		}
		
		UpdateData(FALSE);
	}
	
	*pResult = 0;
}

void CDlgInfoDiffusionPlay::OnSelchangeComboPlayMode() 
{
	// TODO: Add your control notification handler code here
	int nSel = m_cmbPlayMode.GetCurSel();
	if (nSel == CB_ERR)
	{
		return;
	}
	CString strMode;
	m_cmbPlayMode.GetLBText(nSel, strMode);
	if (0 == strcmp(strMode, "byTime"))
	{
		GetDlgItem(IDC_EDIT_PROGRAM_DURATION)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_PLAY_COUNT)->EnableWindow(FALSE);
	}
	else if (0 == strcmp(strMode, "byCount"))
	{
		GetDlgItem(IDC_EDIT_PROGRAM_DURATION)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PLAY_COUNT)->EnableWindow(TRUE);
	}
}
